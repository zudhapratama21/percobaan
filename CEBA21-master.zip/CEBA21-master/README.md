<h2 align="center">
 CEB_A21
</h2>

<p align="center">
 <img src="https://raw.githubusercontent.com/larastaslima/CEBA21/master/res/penyelenggara.png" alt="CfDS x Progate" width="50%" />
</p>

<h4 align="center">
 Hasil Proyek Front-End Tim A21 untuk Coding Experience Bootcamp UGM X PROGATE 2020
</h4>

## Kontributor

:octocat: [larastaslima](https://github.com/larastaslima), [opxop](https://github.com/opxop), [tejow](https://github.com/tejow), [zudha](https://github.com/zudha), dan [choco-beans](https://github.com/choco-beans)
